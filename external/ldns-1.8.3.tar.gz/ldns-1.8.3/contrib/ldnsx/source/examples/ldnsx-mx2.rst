MX2
===

.. literalinclude:: ../../examples/ldnsx-mx2.py
	:language: python
	:linenos:
