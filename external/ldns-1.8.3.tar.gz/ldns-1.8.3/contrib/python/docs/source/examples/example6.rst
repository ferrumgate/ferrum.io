Read zone file
===============================

This example shows how to read the content of a zone file

.. literalinclude:: ../../../examples/ldns-zone.py
   :language: python

Zone file ``zone.txt``:

.. literalinclude:: ../../../examples/zone.txt

