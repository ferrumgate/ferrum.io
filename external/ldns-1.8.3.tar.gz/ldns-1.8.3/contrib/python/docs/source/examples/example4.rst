AXFR client with IDN support
===============================

This example shows how to get AXFR working and how to get involved Internationalized Domain Names (IDN)

.. literalinclude:: ../../../examples/ldns-axfr.py
   :language: python
